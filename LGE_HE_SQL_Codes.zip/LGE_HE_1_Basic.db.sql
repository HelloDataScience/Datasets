-- IRIS에서 전체 필드와 전체 행을 선택합니다.
SELECT * FROM IRIS;

-- IRIS에서 전체 필드와 처음 10행을 선택합니다.
SELECT * FROM IRIS LIMIT 10;

-- IRIS에서 일부 필드와 전체 행을 선택합니다.
SELECT sepal_length, species FROM IRIS;

-- IRIS에서 일부 필드와 처음 10행을 선택합니다.
SELECT sepal_length, species FROM IRIS LIMIT 10;

-- IRIS에서 조건을 만족하는 행을 선택합니다.
SELECT * FROM IRIS WHERE sepal_length >= 5;

-- IRIS에서 두 조건을 모두 만족하는 행을 선택합니다.
SELECT * FROM IRIS WHERE sepal_length >= 5 AND sepal_length <= 7;
SELECT * FROM IRIS WHERE sepal_length BETWEEN 5 AND 7;

-- IRIS에서 두 조건 중 하나라도 만족하는 행을 선택합니다.
SELECT * FROM IRIS WHERE species == 'versicolor' OR species == 'virginica';
SELECT * FROM IRIS WHERE species IN ('versicolor', 'virginica');

-- IRIS에서 sepal_length를 sepal_width로 나눈 sepal_ratio를 생성합니다.
SELECT sepal_length / sepal_width AS sepal_ratio FROM IRIS;

-- IRIS의 전체 필드에 sepal_ratio를 추가합니다.
SELECT *, sepal_length / sepal_width AS sepal_ratio FROM IRIS;

-- IRIS에서 species가 'setosa'인 행을 선택하고 sepal_ratio를 생성합니다.
SELECT *, sepal_length / sepal_width AS sepal_ratio
FROM IRIS
WHERE species == 'setosa';

-- IRIS를 sepal_length 기준으로 오름차순 정렬합니다.
SELECT * FROM IRIS ORDER BY sepal_length ASC;

-- IRIS를 sepal_length 기준으로 내림차순 정렬합니다.
SELECT * FROM IRIS ORDER BY sepal_length DESC;

-- IRIS를 sepal_length와 petal_length 기준으로 오름차순 정렬합니다.
SELECT * FROM IRIS ORDER BY sepal_length, petal_length;

-- IRIS를 sepal_length로는 내림차순, petal_length로는 오름차순 정렬합니다.
SELECT * FROM IRIS ORDER BY sepal_length DESC, petal_length;

-- IRIS의 전체 행 개수를 확인합니다.
SELECT COUNT(*) AS cnt FROM IRIS;

-- IRIS의 species별 행 개수를 확인합니다.
SELECT species, COUNT(*) AS cnt FROM IRIS GROUP BY species;

-- IRIS의 species별 sepal_length의 합계를 확인합니다.
SELECT species, SUM(sepal_length) AS sum FROM IRIS GROUP BY species;

-- IRIS의 species별 sepal_length의 평균을 확인합니다.
SELECT species, AVG(sepal_length) AS avg FROM IRIS GROUP BY species;

- IRIS의 species별 sepal_ratio가 1.5 이상인 행을 선택하고 내림차순 정렬합니다.
SELECT species, sepal_length / sepal_width AS sepal_ratio
FROM IRIS
GROUP BY species
HAVING sepal_ratio >= 1.5
ORDER BY sepal_ratio;

-- 새로운 테이블을 생성합니다.
CREATE TABLE user(
  id INT NOT NULL PRIMARY KEY, 
  name TEXT(10), 
  age INT
);
SElect * from user;

-- 새로 생성한 테이블에 행을 추가합니다.
INSERT INTO user VALUES(1, '김현수', 28);
INSERT INTO user VALUES(2, '이서현', 32);
INSERT INTO user VALUES(3, '박지민', 27);
SElect * from user;

-- 테이블의 값을 변경합니다.
UPDATE user SET name == '최민석' WHERE age < 30;
SElect * from user;

-- 테이블에서 행을 삭제합니다.
DELETE FROM user WHERE age == 27;
SElect * from user;

-- 테이블을 삭제합니다.
DROP TABLE user;
