-- 두 정수로 산술 연산을 실습합니다.
SELECT 5 + 2;
SELECT 5 - 2;
SELECT 5 * 2;
SELECT 5 / 2;
SELECT 5 % 2;

-- 정수를 실수로 변환할 때 REAL(또는 FLOAT)을 지정합니다.
SELECT 5 / CAST(2 AS REAL);
SELECT 5 / 2.0

-- 실수를 정수로 변환할 때 INTEGER(또는 INT)를 지정합니다.
SELECT 5.0 / CAST(2.0 AS INTEGER);
SELECT 5.0 / 2;

-- IRIS_NULL의 수치형 필드로 산술 연산을 실습합니다.
SELECT sepal_width, sepal_width + 2 FROM IRIS_NULL LIMIT 10;
SELECT sepal_width, sepal_width - 2 FROM IRIS_NULL LIMIT 10;
SELECT sepal_width, sepal_width * 2 FROM IRIS_NULL LIMIT 10;
SELECT sepal_width, sepal_width / 2 FROM IRIS_NULL LIMIT 10;
SELECT sepal_width, sepal_width % 2 FROM IRIS_NULL LIMIT 10;

-- 두 정수로 비교 연산을 실습합니다.
SELECT 5 >= 2;
SELECT 5 <= 2;
SELECT 5 == 2;
SELECT 5 != 2;
SELECT 5 IS NULL;
SELECT 5 IS NOT NULL;

-- IRIS_NULL의 수치형 필드로 비교 연산을 실습합니다.
SELECT COUNT(*) FROM IRIS_NULL WHERE sepal_length >= 5;
SELECT COUNT(*) FROM IRIS_NULL WHERE sepal_length <= 5;
SELECT COUNT(*) FROM IRIS_NULL WHERE sepal_length == 5;
SELECT COUNT(*) FROM IRIS_NULL WHERE sepal_length != 5;
SELECT COUNT(*) FROM IRIS_NULL WHERE sepal_length IS NULL;
SELECT COUNT(*) FROM IRIS_NULL WHERE sepal_length IS NOT NULL;

-- 두 조건식으로 논리 연산을 실습합니다.
SELECT 1 == 1 AND 2 != 2;
SELECT 1 == 1 OR 2 != 2;
SELECT NOT 1 == 1;

-- 수치형이 지정한 범위에 포함되는지 여부를 확인합니다.
SELECT 1 BETWEEN 0 AND 2;

-- 문자열이 지정한 목록에 포함되는지 여부를 확인합니다.
SELECT 'B' IN ('A', 'C');

-- 두 문자열의 일치 여부를 확인합니다.
SELECT 'ABC' LIKE 'ABC';
SELECT 'ABC' LIKE 'Abc';
SELECT 'ABC' GLOB 'Abc';
SELECT 'ABC' LIKE 'A';
SELECT 'ABC' LIKE 'A%';
SELECT 'ABC' LIKE 'A_';

-- IRIS의 수치형 필드로 논리 연산을 실습합니다.
SELECT COUNT(*) FROM IRIS WHERE sepal_width < 3 AND petal_width > 2;
SELECT COUNT(*) FROM IRIS WHERE sepal_width < 3 AND NOT (petal_width > 2);
SELECT COUNT(*) FROM IRIS WHERE NOT (sepal_width < 3) AND petal_width > 2;
SELECT COUNT(*) FROM IRIS WHERE sepal_width < 3 OR petal_width > 2;
SELECT COUNT(*) FROM IRIS WHERE NOT (sepal_width < 3 OR petal_width > 2);

-- 특정 범위에 포함된 IRIS의 수치형 필드 원소 개수를 확인합니다.
SELECT COUNT(*) FROM IRIS WHERE sepal_width >= 2 AND sepal_width <= 3;
SELECT COUNT(*) FROM IRIS WHERE sepal_width BETWEEN 2 AND 3;

-- 특정 목록에 포함된 IRIS의 문자열 필드 원소 개수를 확인합니다.
SELECT COUNT(*) FROM IRIS WHERE species IN ('versicolor', 'virginica');
SELECT COUNT(*) FROM IRIS WHERE species LIKE 'v%';

-- UNION은 두 쿼리의 결과에서 중복을 제거하고 하나로 결합합니다.(합집합)
SELECT * FROM IRIS WHERE sepal_length <= 4.4
UNION
SELECT * FROM IRIS_NULL WHERE sepal_length <= 4.4;

-- UNION ALL은 두 쿼리의 결과에서 중복을 제거하지 않습니다.
SELECT * FROM IRIS WHERE sepal_length <= 4.4
UNION ALL
SELECT * FROM IRIS_NULL WHERE sepal_length <= 4.4;

-- INTERSECT는 두 쿼리의 결과에서 중복인 행을 선택합니다.(교집합)
SELECT * FROM IRIS WHERE sepal_length <= 4.4
INTERSECT
SELECT * FROM IRIS_NULL WHERE sepal_length <= 4.4;

-- EXCEPT는 첫 번째 쿼리 결과에서 두 번째 쿼리 결과를 제외합니다.(차집합)
SELECT * FROM IRIS WHERE sepal_length <= 4.4
EXCEPT
SELECT * FROM IRIS_NULL WHERE sepal_length <= 4.4;
