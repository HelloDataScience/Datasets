-- SELECT 절에 지정한 필드명의 중복 원소를 행 개수만큼 반환합니다.
SELECT species FROM IRIS;

-- SELECT 절에서 필드명 앞에 DISTINCT 키워드를 적용하면 해당 필드명에서 중복된 원소를 제거합니다.
SELECT DISTINCT species FROM IRIS;

-- GROUP BY 절을 추가하면 해당 필드명에서 중복된 원소를 제거합니다.
SELECT species FROM IRIS GROUP BY species;

-- 내부 병합은 두 테이블에서 외래키의 원소가 서로 일치하는 행을 선택합니다.
SELECT *
FROM HR_MEMBER
INNER JOIN HR_OFFICE
ON HR_MEMBER.직원명 == HR_OFFICE.직원명;

-- 테이블마다 별칭을 지정하면 코드를 간결하게 작성할 수 있습니다.
SELECT A.*, B.내선, B.부서
FROM HR_MEMBER AS A 
INNER JOIN HR_OFFICE AS B 
ON A.직원명 == B.직원명;

-- JOIN 절을 반복하면 세 개 이상의 테이블에 대한 병합을 실행할 수 있습니다.
SELECT A.*, B.내선, B.부서, C.혈액형, C.동아리
FROM HR_MEMBER AS A 
INNER JOIN HR_OFFICE AS B 
ON A.직원명 == B.직원명 
INNER JOIN HR_PERSON AS C 
ON B.직원명 == C.이름;

-- 외부 병합은 두 테이블에서 외래키의 원소가 서로 일치하지 않는 행을 포함합니다.
SELECT A.*, B.내선, B.부서
FROM HR_MEMBER AS A
FULL OUTER JOIN HR_OFFICE AS B 
ON A.직원명 == B.직원명;

-- 왼쪽 외부 병합은 왼쪽 테이블을 고정한 상태로 외부 병합을 실행합니다.
SELECT A.*, B.내선, B.부서
FROM HR_MEMBER AS A
LEFT OUTER JOIN HR_OFFICE AS B 
ON A.직원명 == B.직원명;

-- 외래키를 두 개 이상 지정하여 왼쪽 외부 병합을 실행합니다.
SELECT A.*, C.혈액형, C.동아리
FROM HR_MEMBER AS A 
LEFT OUTER JOIN HR_PERSON AS C 
ON A.직원명 == C.이름 AND A.나이 == C.나이;

-- 교차 병합은 두 테이블에서 가능한 모든 조합(행)을 생성합니다.
SELECT * 
FROM HR_MEMBER 
CROSS JOIN HR_PERSON;

-- 메인쿼리의 FROM절에 테이블명 대신 서브쿼리 결과를 추가할 수 있습니다.
SELECT *
FROM (SELECT * FROM HR_PERSON WHERE 혈액형 == 'O');

-- 메인쿼리의 WHERE절에 조건식의 일부로 서브쿼리를 사용할 수 있습니다.
SELECT *
FROM HR_MEMBER
WHERE 직원명 IN (SELECT 이름 FROM HR_PERSON WHERE 혈액형 == 'O');

-- 서브쿼리를 활용한 테이블 병합을 실행합니다.
SELECT A.*, B.조직
FROM HR_MEMBER AS A 
INNER JOIN (SELECT *, CONCAT(부서, '-',내선) AS 조직 FROM HR_OFFICE) AS B 
ON A.직원명 == B.직원명;

-- 서브쿼리 코드로 뷰를 생성합니다.
CREATE VIEW HR_OFFICE_V AS
SELECT *, CONCAT(부서, '-',내선) AS 조직 FROM HR_OFFICE

-- 서브쿼리 코드를 뷰로 대체합니다.
SELECT A.*, B.조직
FROM HR_MEMBER AS A
INNER JOIN HR_OFFICE_V AS B
ON A.직원명 == B.직원명;
