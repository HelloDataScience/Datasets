-- IRIS의 수치형 필드로 수학 함수를 실습합니다.
SELECT sepal_length, CEIL(sepal_length) FROM IRIS LIMIT 10;
SELECT sepal_length, FLOOR(sepal_length) FROM IRIS LIMIT 10;
SELECT sepal_length, ROUND(sepal_length, 0) FROM IRIS LIMIT 10;
SELECT sepal_length, POWER(sepal_length, 2) FROM IRIS LIMIT 10;
SELECT sepal_length, SQRT(sepal_length) FROM IRIS LIMIT 10;
SELECT sepal_length, EXP(sepal_length) FROM IRIS LIMIT 10;
SELECT sepal_length, LOG(sepal_length) FROM IRIS LIMIT 10;

-- IRIS의 문자열 필드로 문자열 함수를 실습합니다.
SELECT species, LENGTH(species) FROM IRIS GROUP BY species;
SELECT species, REPLACE(species, 's', 'v') FROM IRIS GROUP BY species;
SELECT species, SUBSTR(species, 1, 3) FROM IRIS GROUP BY species;
SELECT species, INSTR(species, 's') FROM IRIS GROUP BY species;
SELECT species, TRIM(species, 'v') FROM IRIS GROUP BY species;
SELECT species, UPPER(species) FROM IRIS GROUP BY species;
SELECT CONCAT(species, ': ', sepal_length) FROM IRIS GROUP BY species;

-- IRIS_NULL의 수치형 필드로 제어 함수를 실습합니다.
SELECT sepal_length, sepal_width, COALESCE(sepal_length, sepal_width, 0)
FROM IRIS_NULL;

SELECT sepal_length, COALESCE(sepal_length, 0) FROM IRIS_NULL;
SELECT sepal_length, IFNULL(sepal_length, 0) FROM IRIS_NULL;
SELECT sepal_length, NULLIF(sepal_length, 5) FROM IRIS_NULL;

-- IRIS의 수치형 필드로 구간화를 실습합니다.
SELECT sepal_width, 
       IIF(sepal_width > 3.5, 'L', 'S')
FROM IRIS;

SELECT sepal_width,
       IIF(sepal_width > 3.5, 'L', IIF(sepal_width > 3.0, 'M', 'S'))
FROM IRIS;

-- IRIS의 수치형 필드로 구간화를 실습합니다.
SELECT sepal_width,
       CASE WHEN sepal_width > 3.5 THEN 'L' ELSE 'S' END
FROM IRIS;

SELECT sepal_width,
       CASE WHEN sepal_width > 3.5 THEN 'L' 
       WHEN sepal_width > 3.0 THEN 'M' ELSE 'S' END
FROM IRIS;

-- IRIS의 문자열 필드로 구간화를 실습합니다.
SELECT species,
       CASE species WHEN 'setosa' THEN '부채붓꽃'
                    WHEN 'versicolor' THEN '버시컬러' ELSE '버지니카' END
FROM IRIS
GROUP BY species;

-- IRIS의 수치형 필드로 기술 통계량을 확인합니다.
SELECT species,
       COUNT(*) AS cnt,
       SUM(sepal_length) AS sum,
       AVG(sepal_length) AS avg,
       -- STDEV(sepal_length) AS std
       AVG(sepal_length * sepal_length) - AVG(sepal_length)*AVG(sepal_length) as var, 
       SQRT(AVG(sepal_length * sepal_length) - AVG(sepal_length)*AVG(sepal_length)) as std
FROM IRIS
GROUP BY species;

-- 현재 날짜와 시간을 반환합니다.
SELECT DATE('now', 'localtime');
SELECT TIME('now', 'localtime');
SELECT DATETIME('now', 'localtime');

-- DT의 날짜시간 필드로 날짜와 시간을 반환합니다.
SELECT date, DATE(date) FROM DT;
SELECT date, TIME(date) FROM DT;

-- 기준일시로부터 지정한 간격 이전/이후의 날짜 또는 시간 문자열을 반환합니다.
SELECT date, DATE(date, '1 year') FROM DT;
SELECT date, DATE(date, '1 month', '1 day') FROM DT;
SELECT date, DATE(date, 'start of month', '-1 day') FROM DT;
SELECT date, TIME(date, '1 hour') FROM DT;
SELECT date, TIME(date, '1 minute', '1 second') FROM DT;
SELECT date, TIME(date, 'start of day', '-1 second') FROM DT;

-- 기준일시로부터 지정한 날짜시간 포맷의 문자열을 반환합니다.
SELECT date, STRFTIME('%Y년 %m월 %d일', date) FROM DT;
SELECT date, STRFTIME('%H시 %M분 %S초', date) FROM DT;
SELECT date, STRFTIME('%I:%M:%S %p', date) FROM DT;

-- 현재 날짜와 특정일의 간격을 계산합니다.
SELECT (STRFTIME('%s', 'now') - STRFTIME('%s', date)) / 86400 FROM DT;
SELECT JULIANDAY('now') - JULIANDAY(date) FROM DT;
